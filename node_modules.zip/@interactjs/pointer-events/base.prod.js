/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import"../utils/domUtils.prod.js";import"../utils/extend.prod.js";import"../utils/getOriginXY.prod.js";import"./PointerEvent.prod.js";export{a as default}from"./base-PHHQHneY.js";import"../core/BaseEvent.prod.js";import"../utils/pointerUtils.prod.js";
//# sourceMappingURL=base.prod.js.map
