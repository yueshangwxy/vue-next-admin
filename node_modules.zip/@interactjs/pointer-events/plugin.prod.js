/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import{p as pointerEvents}from"./base-PHHQHneY.js";import holdRepeat from"./holdRepeat.prod.js";import plugin$1 from"./interactableTargets.prod.js";import"../utils/domUtils.prod.js";import"../utils/extend.prod.js";import"../utils/getOriginXY.prod.js";import"./PointerEvent.prod.js";import"../core/BaseEvent.prod.js";import"../utils/pointerUtils.prod.js";const plugin={id:"pointer-events",install(t){t.usePlugin(pointerEvents),t.usePlugin(holdRepeat),t.usePlugin(plugin$1)}};export{plugin as default};
//# sourceMappingURL=plugin.prod.js.map
