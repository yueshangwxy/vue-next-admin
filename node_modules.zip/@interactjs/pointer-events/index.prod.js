/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import plugin from"./plugin.prod.js";import interact from"../interact/index.prod.js";import"./base-PHHQHneY.js";import"../utils/domUtils.prod.js";import"../utils/extend.prod.js";import"../utils/getOriginXY.prod.js";import"./PointerEvent.prod.js";import"../core/BaseEvent.prod.js";import"../utils/pointerUtils.prod.js";import"./holdRepeat.prod.js";import"./interactableTargets.prod.js";interact.use(plugin);
//# sourceMappingURL=index.prod.js.map
