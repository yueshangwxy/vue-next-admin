/**
 * interact.js 1.10.27
 *
 * Copyright (c) 2012-present Taye Adeyemi <dev@taye.me>
 * Released under the MIT License.
 * https://raw.github.com/taye/interact.js/main/LICENSE
 */

import "../utils/domUtils.js";
import "../utils/extend.js";
import "../utils/getOriginXY.js";
import './PointerEvent.js';
export { a as default } from './base-45YfudGV.js';
import "../core/BaseEvent.js";
import "../utils/pointerUtils.js";
//# sourceMappingURL=base.js.map
