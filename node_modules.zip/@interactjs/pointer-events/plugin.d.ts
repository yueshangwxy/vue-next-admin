import type { Plugin } from '@interactjs/core/scope';
import './base';
import './holdRepeat';
import './interactableTargets';
declare const plugin: Plugin;
export default plugin;
