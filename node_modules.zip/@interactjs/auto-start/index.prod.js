/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import plugin from"./plugin.prod.js";import interact from"../interact/index.prod.js";import"./base.prod.js";import"../utils/domUtils.prod.js";import"../utils/extend.prod.js";import"../utils/is.prod.js";import"../utils/misc.prod.js";import"./InteractableMethods.prod.js";import"./dragAxis.prod.js";import"./hold.prod.js";interact.use(plugin);
//# sourceMappingURL=index.prod.js.map
