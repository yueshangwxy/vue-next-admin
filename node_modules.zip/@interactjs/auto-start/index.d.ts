import '@interactjs/auto-start/plugin';
