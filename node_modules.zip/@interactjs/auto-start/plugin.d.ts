import type { Scope } from '@interactjs/core/scope';
import './base';
import './dragAxis';
import './hold';
declare const _default: {
    id: string;
    install(scope: Scope): void;
};
export default _default;
