/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import autoStart from"./base.prod.js";import dragAxis from"./dragAxis.prod.js";import hold from"./hold.prod.js";import"../utils/domUtils.prod.js";import"../utils/extend.prod.js";import"../utils/is.prod.js";import"../utils/misc.prod.js";import"./InteractableMethods.prod.js";var plugin={id:"auto-start",install(t){t.usePlugin(autoStart),t.usePlugin(hold),t.usePlugin(dragAxis)}};export{plugin as default};
//# sourceMappingURL=plugin.prod.js.map
