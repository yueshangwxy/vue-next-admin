declare const interact: import("@interactjs/core/InteractStatic").InteractStatic;
export default interact;
