/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import{Scope}from"../core/scope.prod.js";const scope=new Scope,interact=scope.interactStatic,_global="undefined"!=typeof globalThis?globalThis:window;scope.init(_global);export{interact as default};
//# sourceMappingURL=index.prod.js.map
