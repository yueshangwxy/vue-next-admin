import type { ModifierFunction } from './types';
declare const noop: ModifierFunction<any, any, "noop">;
export default noop;
