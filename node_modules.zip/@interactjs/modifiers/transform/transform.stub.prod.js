/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

export{default}from"../noop.prod.js";
//# sourceMappingURL=transform.stub.prod.js.map
