/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

const noop=()=>{};noop._defaults={};export{noop as default};
//# sourceMappingURL=noop.prod.js.map
