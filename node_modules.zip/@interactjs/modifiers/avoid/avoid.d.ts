export { default } from '../noop';
