/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import inertia from"./plugin.prod.js";import interact from"../interact/index.prod.js";import"../modifiers/base.prod.js";import"../offset/plugin.prod.js";import"../modifiers/Modification.prod.js";import"../utils/domUtils.prod.js";import"../utils/hypot.prod.js";import"../utils/is.prod.js";import"../utils/pointerUtils.prod.js";import"../utils/raf.prod.js";interact.use(inertia);
//# sourceMappingURL=index.prod.js.map
