import '@interactjs/inertia/plugin';
