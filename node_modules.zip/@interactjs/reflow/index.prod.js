/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import reflow from"./plugin.prod.js";import interact from"../interact/index.prod.js";import"../utils/arr.prod.js";import"../utils/misc.prod.js";import"../utils/pointerUtils.prod.js";import"../utils/rect.prod.js";interact.use(reflow);
//# sourceMappingURL=index.prod.js.map
