/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import autoScrollPlugin from"./plugin.prod.js";import interact from"../interact/index.prod.js";import"../utils/domUtils.prod.js";import"../utils/is.prod.js";import"../utils/raf.prod.js";import"../utils/rect.prod.js";import"../utils/window.prod.js";interact.use(autoScrollPlugin);
//# sourceMappingURL=index.prod.js.map
