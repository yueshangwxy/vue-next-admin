import '@interactjs/auto-scroll/plugin';
