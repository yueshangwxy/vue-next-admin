/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

var edgeTarget=()=>{};export{edgeTarget as default};
//# sourceMappingURL=edgeTarget.prod.js.map
