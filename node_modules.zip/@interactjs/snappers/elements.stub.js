/**
 * interact.js 1.10.27
 *
 * Copyright (c) 2012-present Taye Adeyemi <dev@taye.me>
 * Released under the MIT License.
 * https://raw.github.com/taye/interact.js/main/LICENSE
 */

var elements_stub = () => {};
export { elements_stub as default };
//# sourceMappingURL=elements.stub.js.map
