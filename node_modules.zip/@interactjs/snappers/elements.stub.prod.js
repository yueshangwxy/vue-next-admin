/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

var elements_stub=()=>{};export{elements_stub as default};
//# sourceMappingURL=elements.stub.prod.js.map
