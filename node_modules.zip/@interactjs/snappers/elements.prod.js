/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

var elements=()=>{};export{elements as default};
//# sourceMappingURL=elements.prod.js.map
