/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import snappersPlugin from"./plugin.prod.js";import interact from"../interact/index.prod.js";import"../utils/extend.prod.js";import"./all-jlnWK4MV.js";import"./edgeTarget.prod.js";import"./elements.prod.js";import"./grid.prod.js";interact.use(snappersPlugin);
//# sourceMappingURL=index.prod.js.map
