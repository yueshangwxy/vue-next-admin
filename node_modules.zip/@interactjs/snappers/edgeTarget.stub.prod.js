/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

var edgeTarget_stub=()=>{};export{edgeTarget_stub as default};
//# sourceMappingURL=edgeTarget.stub.prod.js.map
