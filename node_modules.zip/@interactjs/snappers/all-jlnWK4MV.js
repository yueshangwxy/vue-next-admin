/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import edgeTarget from"./edgeTarget.prod.js";import elements from"./elements.prod.js";import grid from"./grid.prod.js";var allSnappers=Object.freeze({__proto__:null,edgeTarget:edgeTarget,elements:elements,grid:grid});export{allSnappers as a};
//# sourceMappingURL=all-jlnWK4MV.js.map
