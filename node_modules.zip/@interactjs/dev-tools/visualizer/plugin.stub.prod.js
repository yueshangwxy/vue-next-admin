/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

var plugin_stub={};export{plugin_stub as default};
//# sourceMappingURL=plugin.stub.prod.js.map
