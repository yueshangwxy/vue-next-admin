/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

var plugin={};export{plugin as default};
//# sourceMappingURL=plugin.prod.js.map
