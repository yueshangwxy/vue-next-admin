/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import defaultExport from"./plugin.prod.js";import interact from"../interact/index.prod.js";import"../utils/domObjects.prod.js";import"../utils/domUtils.prod.js";import"../utils/extend.prod.js";import"../utils/is.prod.js";import"../utils/isNonNativeEvent.prod.js";import"../utils/normalizeListeners.prod.js";import"../utils/window.prod.js";interact.use(defaultExport);
//# sourceMappingURL=index.prod.js.map
