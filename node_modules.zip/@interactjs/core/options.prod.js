/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

const defaults={base:{preventDefault:"auto",deltaSource:"page"},perAction:{enabled:!1,origin:{x:0,y:0}},actions:{}};export{defaults};
//# sourceMappingURL=options.prod.js.map
