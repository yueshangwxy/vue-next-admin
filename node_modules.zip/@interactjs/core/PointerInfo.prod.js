/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

class PointerInfo{constructor(i,t,o,e,n){this.id=void 0,this.pointer=void 0,this.event=void 0,this.downTime=void 0,this.downTarget=void 0,this.id=i,this.pointer=t,this.event=o,this.downTime=e,this.downTarget=n}}export{PointerInfo};
//# sourceMappingURL=PointerInfo.prod.js.map
