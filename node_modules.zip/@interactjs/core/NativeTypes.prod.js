/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

const NativePointerEvent=null;export{NativePointerEvent};
//# sourceMappingURL=NativeTypes.prod.js.map
