/**
 * interact.js 1.10.27
 *
 * Copyright (c) 2012-present Taye Adeyemi <dev@taye.me>
 * Released under the MIT License.
 * https://raw.github.com/taye/interact.js/main/LICENSE
 */

import * as arr from "../utils/arr.js";
import extend from "../utils/extend.js";
import normalize from "../utils/normalizeListeners.js";
function fireUntilImmediateStopped(event, listeners) {
  for (const listener of listeners) {
    if (event.immediatePropagationStopped) {
      break;
    }
    listener(event);
  }
}
class Eventable {
  constructor(options) {
    this.options = void 0;
    this.types = {};
    this.propagationStopped = false;
    this.immediatePropagationStopped = false;
    this.global = void 0;
    this.options = extend({}, options || {});
  }
  fire(event) {
    let listeners;
    const global = this.global;

    // Interactable#on() listeners
    // tslint:disable no-conditional-assignment
    if (listeners = this.types[event.type]) {
      fireUntilImmediateStopped(event, listeners);
    }

    // interact.on() listeners
    if (!event.propagationStopped && global && (listeners = global[event.type])) {
      fireUntilImmediateStopped(event, listeners);
    }
  }
  on(type, listener) {
    const listeners = normalize(type, listener);
    for (type in listeners) {
      this.types[type] = arr.merge(this.types[type] || [], listeners[type]);
    }
  }
  off(type, listener) {
    const listeners = normalize(type, listener);
    for (type in listeners) {
      const eventList = this.types[type];
      if (!eventList || !eventList.length) {
        continue;
      }
      for (const subListener of listeners[type]) {
        const index = eventList.indexOf(subListener);
        if (index !== -1) {
          eventList.splice(index, 1);
        }
      }
    }
  }
  getRect(_element) {
    return null;
  }
}
export { Eventable };
//# sourceMappingURL=Eventable.js.map
