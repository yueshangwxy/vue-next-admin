export declare const NativePointerEvent: PointerEvent;
export type NativeEventTarget = EventTarget;
export type NativeElement = Element;
