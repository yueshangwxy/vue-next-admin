import '@interactjs/actions/resize/plugin';
