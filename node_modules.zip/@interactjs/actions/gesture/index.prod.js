/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import gesture from"./plugin.prod.js";import interact from"../../interact/index.prod.js";import"../../utils/is.prod.js";import"../../utils/pointerUtils.prod.js";interact.use(gesture);
//# sourceMappingURL=index.prod.js.map
