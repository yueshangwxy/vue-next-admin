/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import plugin from"./plugin.prod.js";import interact from"../interact/index.prod.js";import"./drag/plugin.prod.js";import"../utils/is.prod.js";import"./drop/plugin.prod.js";import"../utils/domUtils.prod.js";import"../utils/extend.prod.js";import"../utils/getOriginXY.prod.js";import"../utils/normalizeListeners.prod.js";import"../utils/pointerUtils.prod.js";import"./drop/DropEvent.prod.js";import"../core/BaseEvent.prod.js";import"../utils/arr.prod.js";import"./gesture/plugin.prod.js";import"./resize/plugin.prod.js";interact.use(plugin);
//# sourceMappingURL=index.prod.js.map
