/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import drag from"./plugin.prod.js";import interact from"../../interact/index.prod.js";import"../../utils/is.prod.js";interact.use(drag);
//# sourceMappingURL=index.prod.js.map
