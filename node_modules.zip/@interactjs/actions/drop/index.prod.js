/* interact.js 1.10.27 | https://raw.github.com/taye/interact.js/main/LICENSE */

import drop from"./plugin.prod.js";import interact from"../../interact/index.prod.js";import"../../utils/domUtils.prod.js";import"../../utils/extend.prod.js";import"../../utils/getOriginXY.prod.js";import"../../utils/is.prod.js";import"../../utils/normalizeListeners.prod.js";import"../../utils/pointerUtils.prod.js";import"../drag/plugin.prod.js";import"./DropEvent.prod.js";import"../../core/BaseEvent.prod.js";import"../../utils/arr.prod.js";interact.use(drop);
//# sourceMappingURL=index.prod.js.map
