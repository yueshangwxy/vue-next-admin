import {
  English
} from "./chunk-MCSDG6XK.js";
import "./chunk-ROME4SDB.js";
export {
  English as default
};
//# sourceMappingURL=element-plus_es_locale_lang_en.js.map
